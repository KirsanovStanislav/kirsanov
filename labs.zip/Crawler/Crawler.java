import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashSet;

public class Crawler
{
	private static final int MAX_DEPTH = 10;
	private HashSet<String> links;

	public Crawler()
	{
		links = new HashSet<>();
	}

	public void getPageLinks(String URL, int depth)
	{
		if ((!links.contains(URL) && (depth < MAX_DEPTH)))
		{
			System.out.println(">> Depth: " + depth + " " + URL);
			try
			{
				links.add(URL);

				Document document = Jsoup.connect(URL).get();
				Elements linksOnPage = document.select("a[href]");

				depth++;
				for (Element page : linksOnPage)
				{
					getPageLinks(page.attr("abs:href"), depth);
				}
			}
			catch (IOException e)
			{
				System.err.println("For '" + URL + "': " + e.getMessage());
			}
		}
	}
	public static void main(String args[])
	{
		int depth = 0;
		String url = "";

		if (args.length != 2)
		{
			System.out.println("Usage: java Crawler <URL> <depth>");
			System.exit(1);
		}
		else
		{
			try
			{
				depth = Integer.parseInt(args[1]);
				url = args[0];
			}
			catch (NumberFormatException e)
			{
				System.out.println("Usage: java Crawler <URL> <depth>");
				System.exit(1);
			}
		}

		new Crawler().getPageLinks(url, depth);
	}
}